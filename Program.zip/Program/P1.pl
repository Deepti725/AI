sum(X,Y,S):- S is X+Y.
